//
//  Insights1.swift
//  Companion
//
//  Created by Shikha Charadva on 11/10/22.
//

import SwiftUI
import Foundation
import UIKit
import HealthKit

struct Insights1: View {
    private let healthStore = HKHealthStore()
    private let stepsQuantityType = HKQuantityType.quantityType(forIdentifier: .stepCount)!
    var body: some View {
      
        NavigationView {
            VStack {
               
                Spacer()
                Header1()
                ScrollView(.vertical, showsIndicators: false){
                  
                    
                    Divider()
                    
                    Post1()
                 
                    Spacer()
                    Spacer()
                    Spacer()
                    
                    HStack {
                        
                        
                        Spacer()
                        
                  
                    }
                }
            
                Spacer()
             
            }
        }
    
       
   
    }
}


struct PostHeader1: View {
    @State private var textInput1: String = ""
    @State private var textInput2: String = ""
    @State private var textInput3: String = ""
    @State private var textInput4: String = ""
   
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 12){
                
               
                
                Text("Enter your details")
                    .font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.black).frame(width: 200, height: 60)
                
                Text("AGE")
                    .font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.black).frame(width: 80, height: 30)
               
                TextField(
                  "Age",
                   text: $textInput1
                ).textFieldStyle(.roundedBorder)
               // .padding(1.0)
                .accessibilityHidden(false)
                //.frame(width: 200.0, height: 40)
                .accessibilityLabel(/*@START_MENU_TOKEN@*/"Label"/*@END_MENU_TOKEN@*/)
               // .accessibilityHint("Enter Your Name")
                .font(.system(size: 25))
                .foregroundColor(.red)
                
                Text("SEX")
                    .font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.black).frame(width: 80, height: 30)
               
                TextField(
                  "Sex",
                   text: $textInput2
                ).textFieldStyle(.roundedBorder)
               // .padding(1.0)
                .accessibilityHidden(false)
                //.frame(width: 200.0, height: 40)
                .accessibilityLabel(/*@START_MENU_TOKEN@*/"Label"/*@END_MENU_TOKEN@*/)
               // .accessibilityHint("Enter Your Name")
                .font(.system(size: 25))
                .foregroundColor(.red)
                
                Text("BP")
                    .font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.black).frame(width: 80, height: 30)
               
                TextField(
                  "Blood Pressure",
                   text: $textInput3
                ).textFieldStyle(.roundedBorder)
               // .padding(1.0)
                .accessibilityHidden(false)
                //.frame(width: 200.0, height: 40)
                .accessibilityLabel(/*@START_MENU_TOKEN@*/"Label"/*@END_MENU_TOKEN@*/)
               // .accessibilityHint("Enter Your Name")
                .font(.system(size: 25))
                .foregroundColor(.red)
           
                Text("CHOLESTEROL")
                    .font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.black).frame(width: 170, height: 30)
                
                TextField(
                  "Cholesterol",
                   text: $textInput3
                ).textFieldStyle(.roundedBorder)
               // .padding(1.0)
                .accessibilityHidden(false)
                //.frame(width: 200.0, height: 40)
                .accessibilityLabel(/*@START_MENU_TOKEN@*/"Label"/*@END_MENU_TOKEN@*/)
               // .accessibilityHint("Enter Your Name")
                .font(.system(size: 25))
                .foregroundColor(.red)
              
            }
           
            
           
        }
      
    }
}

struct PostContent1: View {
    var image: String = "dog"
    
    var body: some View {
        VStack(spacing: 0.0){
            Image(image)
                .resizable()
              
                
            
            HStack{
            
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
        }
    }
}
struct Insights1_Previews: PreviewProvider {
    static var previews: some View {
            Insights1()
     
    }
}
struct Post1: View {
    var image: String = "profile"
    var image1: String = "Doctor"
    //var description: String = "1. What should we call you"
    
    var body: some View {
       PostHeader1().background(
        Image(image1)
            .resizable()
                            .aspectRatio( contentMode: .fill)
                            .clipped().opacity(0.075))
                        .edgesIgnoringSafeArea(.all)
     
    }
}
struct Header1: View {
    var body: some View {
        HStack(spacing: -30
        ) {
            VStack(alignment: .leading, spacing: -50){Image("logo").resizable().aspectRatio(contentMode: .fit).padding(.vertical).frame(width: 150, height: 120)
                
                Text("Good Day! <Name>").font(.system(size: 20)).fontWeight(.bold).foregroundColor(Color.gray).frame(width: 220, height: 50)
                
           
            }
         
            
         
           Spacer()
                .frame(width: 150,height: 70)
            
         
         
        }    .frame(width: 100,height: 130)
     
    }
}

